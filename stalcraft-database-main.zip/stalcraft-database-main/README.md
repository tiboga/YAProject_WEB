# Database of Stalcraft items


Stores information about most of the in-game items in json format. Changes to this repository are automatically pushed when game is updated.

See [developer's documentation](https://eapi.stalcraft.net/items.html) to learn how to work with this data.
